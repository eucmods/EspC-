#include "Typeface.h"

jobject Typeface::create(const char *family, int style) {
    jstring fam = env->NewStringUTF(family);

    jobject result = env->CallStaticObjectMethod(this->typefaceObj, this->createMethod, fam, style);

    env->DeleteLocalRef(fam);

    return result;
}

/*
fixed for Free Fire 
by CMODs
telegram @CoRingaModzYT
youtube Tekashi CMods
day :2021

*/