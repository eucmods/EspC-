#ifndef TURKSAT_H
#define TURKSAT_H

struct {///Tudo V1.68.1
	uintptr_t PeS = 0x204; //1.66
	uintptr_t HeadTF = 0x1F8; //protected Transform JIMLGADEEEB;
	uintptr_t HipTF = 0x1FC; //protected Transform ECBHDOHKAJK;
    uintptr_t ToeTF = 0x20C; //protected Transform PHNOKCJOOJD;
    uintptr_t RShoulder = 0x228; // protected Transform EKEIMDDMFDG;
    uintptr_t LShoulder = 0x22C; //protected Transform GOCJFBEHCAC;
    uintptr_t MainCameraTransform = 0x7C; //public Transform MainCameraTransform;
    uintptr_t Dictionary = 0x44;
	uintptr_t IsClientBot = 0x100;
    uintptr_t Component_GetTransform = 0x337482C;
	uintptr_t Transform_INTERNAL_SetPosition = 0x31B0C98;
    uintptr_t Transform_INTERNAL_GetPosition = 0x31B0BF8;
	uintptr_t WorldToScreenPoint = 0x3371FB8;
	uintptr_t GetAttackableCenterWS = 0xABAE4C;
    uintptr_t GetForward = 0x31B1758;	
    uintptr_t GetLocalPlayer = 0x194FA2C;
    uintptr_t Curent_Match = 0x136284C;
    uintptr_t Camera_main = 0x337292C;
    uintptr_t get_IsFiring = 0xB14C88;
    uintptr_t get_IsSighting = 0xB4BCEC;
    uintptr_t get_isLocalTeam = 0xAC9F98;
    uintptr_t get_isVisible = 0xAC1A88;
	uintptr_t get_CurHp = 0x1E14EE4;
    uintptr_t get_MaxHP = 0xAFEA68;
    uintptr_t get_IsDieing = 0xABD180;
    uintptr_t set_aim = 0xABE4E0;
	uintptr_t get_NickName = 0xABB838;
    uintptr_t get_Chars = 0x33C3F10;
	uintptr_t get_isAlive = 0xB1E204;//1.68
} Turksat;
#endif


