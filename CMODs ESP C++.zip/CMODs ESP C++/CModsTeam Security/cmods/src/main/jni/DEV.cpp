#include <pthread.h>
#include <jni.h>
#include <Substrate/SubstrateHook.h>
#include "Unity/Unity.h"
#include "Dev/Tekashi.h"
#include "Dev/Turksat.h"
#include "ESPHack/Canvas.h"
#include "ESPHack/Rect.h"
#include "ESPHack/Paint.h"
#include "ESPHack/Typeface.h"
#include "Unity/Color.hpp"
#include "memory/Memory.h"
#include <ESPHack/ChamsHack.h>

/*
Caso tenha duvida me chama no telegram

@CoRingaModzYT

chama caso queira ajuda.

criado  na data
2021
*/



#define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so",offset)
#define TEKASHI(offset, ptr, orig) DevelopersTeamHook((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

extern "C" {
JNIEXPORT jstring JNICALL
Java_com_cmods_team_ff_MLoader_Title(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("CMODS TEAM LIB / libcmods.so");
}
JNIEXPORT jstring JNICALL
Java_com_cmods_team_ff_MLoader_Heading(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("Free Fire V1.68.1");
}


JNIEXPORT jobjectArray JNICALL
Java_com_cmods_team_ff_MLoader_getFeatureListttttttttt(JNIEnv *env,jobject activityObject)
{jobjectArray ret;
    const char *features[] = {
		///////////////AIM-BOT////////////////
		    "Category_AIM - BOT",
			
		    "ToggleAIMBOT_Aim Head (Fire) ",//[1]
           
			"SeekBar_AimFOV_0_360",//[2]
		
		    "Toggle_Ant Detect Hack (Ptrace)",//[0]
		 
			"Category2_ESP - HACK",
			
			"Toggle_ESP Line",//[3]
			
			"Toggle_ESP Name",//[4]
			
			"Toggle_ESP Box",//[5]
			
			"Toggle_ESP Distance",//[6]
			
			"Category2_CHAMS - HACK",

			"Toggle_Default Chams",//7
			
            "Toggle_Shading Chams",//8
			
            "Toggle_Rainbow Chams",//9
			
            "Toggle_Wireframe Chams",//10
		
            "Toggle_Glow Chams",//11
			
            "Toggle_Outline Chams",//12
			
            "SeekBar2_Chams Width_0_15",//13
			
            "SeekBar2_Color Color y_0_255",//14 255
			
            "SeekBar2_Color Color z_0_255",//15 255
			
            "SeekBar2_Color Color x_0_255",//16 255
			
			};

    int Total_Feature = (sizeof features /
                         sizeof features[0]);

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

struct Patch {
	
   // Memory aimlock1;
   
}Tekashi;


struct {
	////MODD////
    bool aimFire = false;
    bool FOV = true;
    bool espDistance = false;
	bool espDistance2 = false;
    bool espName = false;
    bool espBox = false;
	bool espLine = false;
	bool BypassProxy = false;
	
    Color LineColor = Color::White();
    Color TextColor = Color::White();
    
	float Fov_Aim = 0.0f;
    float size = 17.0f;
    float LineSize = 1.5f;
	float strokeSize = 1;
} CM;

bool active = true;
bool launched = false;

JNIEXPORT void JNICALL
Java_com_cmods_team_ff_MLoader_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint Value) {
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", Value);
    switch (feature) {
	    
		case 0:
			///Category MENU AIMBOT
            break;
		   
			case 1:
            CM.aimFire = !CM.aimFire;
            break;
			
        case 2:
			CM.Fov_Aim = (float)Value;
			if(Value == 0) {
				CM.Fov_Aim = 0.0f;
			}
            break;
		
        case 3:
			CM.BypassProxy = !CM.BypassProxy;
            break;
			
			case 4:
			//Category MENU ESP
            break;
			
           case 5:
            CM.espLine = !CM.espLine;
            break;
			
			case 6:
            CM.espName = !CM.espName;
            break;
			
			case 7:
            CM.espBox = !CM.espBox;
            break;
		
			case 8:
            CM.espDistance = !CM.espDistance;
            break;
			
			case 9:
			//Category MENU CHAMS HACK
            break;
			
			case 10:
            defchams = !defchams;
            break;
			
			case 11:
            chams = !chams;
            break;
			
			case 12:
            rainbow = !rainbow;
            break;
			
			case 13:
            wire = !wire;
            break;
			
			case 14:
            glow = !glow;
            break;
			
			case 15:
            outline = !outline;
            break;
			
			case 16:
            linewidth = Value;
            break;
			
			case 17:
            r = Value / 255;
            break;
			
			case 18:
            g = Value / 255;
            break;
			
			case 19:
            b = Value / 255;
            break;
    }
  }
}
int (*screenWidth)() = (int(*)())getRealOffset(0x31A6224);///V1.68
int (*screenHeight)() = (int(*)())getRealOffset(0x31A62A8);//1.68

Vector3 GetHeadPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Turksat.HeadTF));
}
Vector3 GetHipPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Turksat.HipTF));
}

Vector3 GetToePosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Turksat.ToeTF));
}

Vector3 GetRShoulderPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Turksat.RShoulder));
}

Vector3 GetLShoulderPosition(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Turksat.LShoulder));
}

Vector3 CameraMain(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Turksat.MainCameraTransform));
}




void *get_CMODS = nullptr;
struct enemy_t {
    void *object;
    Vector3 location;
    int health;
    
};
void *get_Tekashi(void *CoRingaModz) {
      get_CMODS = CoRingaModz;
      return get_CMODS;
}




void *GetClosestEnemy(void *match) {
    if(!match) {
        return NULL;
    }
    float shortestDistance = 99999.0f;
    float maxAngle = CM.Fov_Aim;
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
    if(LocalPlayer != NULL && !get_IsDieing(LocalPlayer)) {
        monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + Turksat.Dictionary);
        for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
            if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
                Vector3 PlayerPos = GetHipPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
                if(CM.FOV) {
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
                    if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                        }
                    }
                } else {
                    if(maxAngle < shortestDistance) {
                        shortestDistance = maxAngle;
                        closestEnemy = Player;
                    }
                }
            }
        }
    }
    return closestEnemy;
}

class ESPManager {///ESP LIST PLAYER ETC...
public:
    std::vector<enemy_t *> *enemies;

    ESPManager() {
        enemies = new std::vector<enemy_t *>();
    }

    bool isEnemyPresent(void *enemyObject) {
        for (std::vector<enemy_t *>::iterator it = enemies->begin(); it != enemies->end(); it++) {
            if ((*it)->object == enemyObject) {
                return true;
            }
        }
        return false;
    }

    void removeEnemy(enemy_t *enemy) {
        for (int i = 0; i < enemies->size(); i++) {
            if ((*enemies)[i] == enemy) {
                enemies->erase(enemies->begin() + i);
                return;
            }
        }
    }

    void tryAddEnemy(void *enemyObject) {
        if (isEnemyPresent(enemyObject)) {
        return;
        }

        if (get_isVisible(enemyObject)) {
        return;
        }

        enemy_t *newEnemy = new enemy_t();

        newEnemy->object = enemyObject;

        enemies->push_back(newEnemy);
    }

    void updateEnemies(void *enemyObject) {
        for (int i = 0; i < enemies->size(); i++) {
            enemy_t *current = (*enemies)[i];

            if (get_isVisible(current->object)) {
                enemies->erase(enemies->begin() + i);
            }
            if ((get_isLocalTeam(get_CMODS) == get_isLocalTeam(current->object))) {
                enemies->erase(enemies->begin() + i);
            }
        }
    }

    void removeEnemyGivenObject(void *enemyObject) {
        for (int i = 0; i < enemies->size(); i++) {
            if ((*enemies)[i]->object == enemyObject) {
                enemies->erase(enemies->begin() + i);
                return;
            }
        }
    }
};
ESPManager *espManager;


static bool isEspReady() {
	return false;
}
void ESP_CMODs(JNIEnv *env, jclass clazz, jobject canvas, int screenWidth, int screenHeight, float screenDensity) {
	static Canvas *m_Canvas = 0;
    if (!m_Canvas) {
        m_Canvas = new Canvas(env, screenWidth, screenHeight, screenDensity);
    }
    if (!m_Canvas)
	return;
    m_Canvas->UpdateCanvas(canvas);
	m_Canvas->drawCircle(screenWidth / 2, screenHeight / 2, CM.Fov_Aim, 1.0f, false, ARGB(255, 0, 255, 0));
	//m_Canvas->drawText("Criador Por CoRingaModz",(screenWidth / 2, screenHeight / 4),26.0f);
	void *TeamSeo = get_CMODS;
	if (TeamSeo != nullptr) {
		void *current_Match = Curent_Match();
		void* local_player = GetLocalPlayer(current_Match);
		if (local_player != nullptr && current_Match != nullptr) {
			if (!isEspReady()) {
			m_Canvas->UpdateCanvas(canvas);///Teste
			
			if (espManager->enemies->empty()) {
            return;
			}
			for (int i = 0; i < espManager->enemies->size(); i++) {

            void *closestEnemy = (*espManager->enemies)[i]->object;
	
			void *camera = Camera_main();
			if (closestEnemy != local_player && closestEnemy != nullptr && get_isVisible(closestEnemy) && !get_isLocalTeam(closestEnemy)) {
					
			void *PeS = *(void **) ((uintptr_t) closestEnemy + Turksat.PeS);
										
             void *HeadTF = *(void **) ((uintptr_t) closestEnemy + Turksat.HeadTF);
			 if (HeadTF != NULL && PeS != NULL) {
										
				Vector3 Pes = Transform_INTERNAL_GetPosition(PeS);
											
				Vector3 Head = Transform_INTERNAL_GetPosition(HeadTF);
	
				Vector3 PositionHead = WorldToScreenPoint(camera, Head);
				PositionHead.Z += 12.5f;
								
				Vector3 PositionPeS = WorldToScreenPoint(camera, Pes);
				
				if (PositionHead.Z > 0 && PositionPeS.Z > 0) {
								
				Vector3 CenterWS = GetAttackableCenterWS(local_player);
											
				float distance = Vector3::Distance(CenterWS, Head);
							
				float lineSize = m_Canvas->scaleSize(0.75f);
				
				 char buffer[10];
                 sprintf(buffer, "[ %.f M ]", distance);     
											
				 monoString *name = get_NickName(closestEnemy);
				 if(name != NULL) {
					int nick_Len = name ->getLength();
						std::string name1;      
						for(int i = 0; i < nick_Len; i++) {
							char data = get_Chars(name, i);
							name1 += isascii(data) ? data : 'dec';
					}
					
					if (CM.espLine) {
						if(get_IsDieing(closestEnemy)) {
							Vector2 From = Vector2(screenWidth / 2, 0);
							m_Canvas->drawLine(From.X, From.Y, screenWidth - (screenWidth - PositionHead.X), (screenHeight - PositionHead.Y), lineSize, 0xffff0000);
							} else {
							Vector2 From = Vector2(screenWidth / 2, 0);
							m_Canvas->drawLine(From.X, From.Y, screenWidth - (screenWidth - PositionHead.X), (screenHeight - PositionHead.Y), lineSize, 0xffffffff);
						}
				}
				    if (CM.espName) {
							std::string nickname3;         
							nickname3 += "[ ";
							nickname3 += name1;
							nickname3 += " ]";
							m_Canvas->drawText(nickname3.c_str(), screenWidth - (screenWidth - PositionHead.X), (screenHeight - PositionHead.Y - 12.0f));
						}
					if (CM.espDistance){
							m_Canvas->drawText(buffer,screenWidth - (screenWidth - PositionPeS.X), (screenHeight - PositionPeS.Y + 12.0f));
						}
					if (CM.espBox) {
							float boxHeight = ((PositionHead.Y - PositionPeS.Y));
							float boxWidth = boxHeight * 0.65f;
							Vector3 vBox = {PositionHead.X - (boxWidth / 2), (screenHeight - PositionHead.Y)};
							m_Canvas->drawBorder(vBox.X, vBox.Y, boxWidth, boxHeight, 1.f, YELLOW);
						}/*
						  else {
                      espManager->removeEnemyGivenObject(closestEnemy);
				      }*/
					}
                 }
              }
           }
       }
    }
 }
}
}





void (*Update)(void* gamestartup);
void _Update(void* gamestartup) {
	if(Update) {
        void* Match = Curent_Match();
        if((CM.aimFire) && Match) {
            void* LocalPlayer = GetLocalPlayer(Match);
            if(LocalPlayer) {
                void* closestEnemy = GetClosestEnemy(Match);
                if(closestEnemy) {
					espManager->tryAddEnemy(gamestartup);
					espManager->updateEnemies(gamestartup);
                    Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
                    Vector3 PlayerLocation = CameraMain(LocalPlayer);
                    Vector3 CenterWS = GetAttackableCenterWS(LocalPlayer);
                    Quaternion PlayerLook = GetRotationToLocation(GetHeadPosition(closestEnemy), 0.1f, PlayerLocation);                  
                    float distance = Vector3::Distance(CenterWS, EnemyLocation);
                    Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
                    Vector3 PlayerHeadPos = GetHeadPosition(closestEnemy);
                    bool scope = get_IsSighting(LocalPlayer);
                    bool firing = get_IsFiring(LocalPlayer);
                    bool caido = get_IsDieing(closestEnemy);
                    if (firing && CM.aimFire) {
                    set_aim(LocalPlayer, PlayerLook);
		            }
              }
           }
        }
	 }
  get_Tekashi(gamestartup);
  Update(gamestartup);
}

void (*destroy)(void *gamestartup);
void _destroy(void *gamestartup) {
    if (gamestartup != NULL) {
        Update(gamestartup);     
        espManager->removeEnemyGivenObject(gamestartup);
    }
}

JNIEXPORT jint JNICALL
Java_com_cmods_team_ff_MLoader_onDraw1(JNIEnv *env,jclass type,jobject espcanvas){
}

static void(*coringa)(int *entryId, monoString *openId);
static void _coringa(int *entryId, monoString *openId){
    return;
}

bool(*anthack)(void* _this);
bool _anthack(void* _this){
return false;
}

void (*OpenWaitingRoomEPRanking)(void* _this);
void  _OpenWaitingRoomEPRanking(void* _this){
 return false;
}

void (*LogAndroidApplicationDetection)(void* _this);
void _LogAndroidApplicationDetection(void* _this){
return false;
}

bool (*FirebaseLogger)(void* _this, int value);
bool _FirebaseLogger(void* _this, int value){
    if (_this != NULL){
        if (CM.BypassProxy){
            return false;
        }
    }
    return FirebaseLogger(_this, value);
}

void *hack_thread(void *) {
LOGI("Loading...");
    ProcMap il2cppMap;
    do {
        il2cppMap = Ptrace::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid()&& mlovinit());//1.68.1
	espManager = new ESPManager();
	auto p_glGetUniformLocation = (const void*(*)(...))dlsym(handle, "glGetUniformLocation");
    auto p_glDrawElements = (const void*(*)(...))dlsym(handle, "glDrawElements");
    DevelopersTeamHook(reinterpret_cast<void*>(p_glGetUniformLocation), reinterpret_cast<void*>(new_glGetUniformLocation), reinterpret_cast<void**>(&old_glGetUniformLocation));
    DevelopersTeamHook(reinterpret_cast<void*>(p_glDrawElements), reinterpret_cast<void*>(new_glDrawElements), reinterpret_cast<void**>(&old_glDrawElements));
	
    TEKASHI(0x1BCC3B4, _Update, Update); // GameStartUp Update v1.68.1
	TEKASHI(0xE095004, _destroy, destroy);//v1.60
	
	TEKASHI(0x1D76928, _coringa, coringa); //private static extern void AnoSDKInit(int gameID) { }
	TEKASHI(0xC15264, _OpenWaitingRoomEPRanking, OpenWaitingRoomEPRanking);
	TEKASHI(0x19849F4, _LogAndroidApplicationDetection, LogAndroidApplicationDetection);
	TEKASHI(0x28DFBC4, _anthack, anthack);//public bool get_is_hacker()
	TEKASHI(0x28DFBCC, _anthack, anthack);//public void set_is_hacker(bool value) { }
	TEKASHI(0x28DFBBC, _anthack, anthack);//public void set_basic_info(AccountMatchInfo value) { }
	TEKASHI(0x28DFF10, _anthack, anthack);//private void set_pregame_infos(List<MatchPregameInfo> value) { }
	
	TEKASHI(0x41DCD04, _FirebaseLogger, FirebaseLogger);///internal static bool get_CanRedirectNativeLogs
	TEKASHI(0x28C6E68, _FirebaseLogger, FirebaseLogger);//private static string <get_DeviceIdentifier>m__0(byte item) { }
	TEKASHI(0x28C1B10, _FirebaseLogger, FirebaseLogger);//public static void GotoApplicationDetailsSettings
	TEKASHI(0x26B8728, _FirebaseLogger, FirebaseLogger);//public void BlockPlayerRequest(ulong blockID, bool need_slience = False)
	TEKASHI(0x26AE3BC, _FirebaseLogger, FirebaseLogger);//public void RequestAccountInfo(ulong accountId, Action<AccountInfoBasic> onFinished) { }
	TEKASHI(0x26AA8C8, _FirebaseLogger, FirebaseLogger);//public List<FriendAccountInfo> get_BlackListAccountInfo() { }
	TEKASHI(0x26AAD34, _FirebaseLogger, FirebaseLogger);//public int get_BlackListCount()
	TEKASHI(0xED60E4, _FirebaseLogger, FirebaseLogger);//public class AndroidApplicationToDetectData
	//TEKASHI(0x14FE824, _FirebaseLogger, FirebaseLogger);//private void ProcessAccountForbidden(BlacklistInfoRes blackList
	TEKASHI(0x28DFBB4, _FirebaseLogger, FirebaseLogger);//public AccountMatchInfo get_basic_info
	TEKASHI(0x1503828, _FirebaseLogger, FirebaseLogger); //private void DetectAndroidApplications(CSGetAndroidApplicationToDetectRes androidApplicationToDetectRes) { }
	TEKASHI(0x197B8D0, _FirebaseLogger, FirebaseLogger); //private static void SendCachedLogs() { }
	TEKASHI(0x1986D64, _FirebaseLogger, FirebaseLogger); //public static void SendLogLeaveGame() { }
	TEKASHI(0x1982F38, _FirebaseLogger, FirebaseLogger); //public static void LogReportCheat(ulong cheater, uint reason, IHAAMHPPLMG cheaterPlayerID, uint[] subReason) { }
	TEKASHI(0x19849F4, _FirebaseLogger, FirebaseLogger); //public static void LogAndroidApplicationDetection(List<int> installedIDs)
	return NULL;
}

static JNINativeMethod methods[] = {{"onDraw1",  "(Landroid/graphics/Canvas;IIF)V", (void *)ESP_CMODs},};
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
	jclass clazz = env->FindClass("com/cmods/team/ff/MLoader");
    env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0]));
    if (!launched) {
        launched = true;
        pthread_t ptid;
        pthread_create(&ptid, 0, hack_thread, 0);
    }
    return JNI_VERSION_1_6;
}

/*
fixed for Free Fire 
by CMODs
telegram @CoRingaModzYT
youtube Tekashi CMods
day :2021

*/
