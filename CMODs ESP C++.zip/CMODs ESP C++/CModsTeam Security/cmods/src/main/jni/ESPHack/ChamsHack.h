#ifndef CHAMSHACK_H
#define CHAMSHACK_H

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <dlfcn.h>
#include <Substrate/SubstrateHook.h>
#include <Includes/Logger.h>


//Chams
static void *handle;

float r, g, b, linewidth = 2.1f;

bool chams = false, wire = false, glow = false, rainbow = false;

float redd = 255, greenn = 0, bluee = 255;

bool outline = false;

bool defchams = false;

int rgb = 1;

bool rF = true, gF, bF = true, rF_, gF_, bF_;


using namespace std;
std::string utf16le_to_utf8(const std::u16string &u16str) {
    if (u16str.empty()) { return std::string(); }
    const char16_t *p = u16str.data();
    std::u16string::size_type len = u16str.length();
    if (p[0] == 0xFEFF) {
        p += 1;
        len -= 1;
    }

    std::string u8str;
    u8str.reserve(len * 3);

    char16_t u16char;
    for (std::u16string::size_type i = 0; i < len; ++i) {

        u16char = p[i];

        if (u16char < 0x0080) {
            u8str.push_back((char) (u16char & 0x00FF));
            continue;
        }
        if (u16char >= 0x0080 && u16char <= 0x07FF) {
            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));
            continue;
        }
        if (u16char >= 0xD800 && u16char <= 0xDBFF) {
            uint32_t highSur = u16char;
            uint32_t lowSur = p[++i];
            uint32_t codePoint = highSur - 0xD800;
            codePoint <<= 10;
            codePoint |= lowSur - 0xDC00;
            codePoint += 0x10000;
            u8str.push_back((char) ((codePoint >> 18) | 0xF0));
            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));
            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));
            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));
            continue;
        }
        {
            u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));
            u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));
            u8str.push_back((char) ((u16char & 0x3F) | 0x80));
            continue;
        }
    }

    return u8str;
}
void performRGBChange() {
    switch (rgb) {
        case 0: {
            if (gF) {
                greenn--;
                if (!greenn) { gF = !gF;  rF_ = !rF_; }
                break; }

            if (redd < 255 && rF_) redd++;
            else { rgb++; redd = 255; rF = !rF; rF_ = !rF_; }
            break; } case 1: {
            if (bF) {
                bluee--;
                if (!bluee) { bF = !bF; gF_ = !gF_; }
                break; }

            if (greenn < 255 && gF_) greenn++;
            else { rgb++; greenn = 255; gF = !gF; gF_ = !gF_; }
            break;} case 2: {
            if (rF) {
                redd--;
                if (!redd) { rF = !rF; bF_ = !bF_; }
                break; }

            if (bluee < 255 && bF_) bluee++;
            else { rgb = 0; bluee = 255; bF = !bF; bF_ = !bF_; }
        }
    }
}
int (*old_glGetUniformLocation)(GLuint, const GLchar *);
GLint new_glGetUniformLocation(GLuint program, const GLchar *name) {
    return old_glGetUniformLocation(program, name);
}
void (*old_glDrawElements)(GLenum mode, GLsizei count, GLenum type, const void *indices);
void new_glDrawElements(GLenum mode, GLsizei count, GLenum type, const void *indices) {
    old_glDrawElements(mode, count, type, indices);
    if (mode != GL_TRIANGLES || count < 1000) return;
    {
        GLint currProgram;
        glGetIntegerv(GL_CURRENT_PROGRAM, &currProgram);
        GLint id = old_glGetUniformLocation(currProgram, "_Texture");//add Material do Player game you
        if (id == -1) return;
        if (chams) {
            glDepthRangef(1, 0.5);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_COLOR, GL_CONSTANT_COLOR);
            glBlendEquation(GL_FUNC_ADD);
            glBlendColor(r, g, b, 1.000);
            glDepthFunc(GL_ALWAYS);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
            glColorMask(r, g, b, 255);
            glBlendFunc(GL_DST_COLOR, GL_ONE);
            glDepthFunc(GL_LESS);
            glDepthMask(true);
            glDepthMask(false);
            glBlendColor(0.0, 0.0, 0.0, 0.0);
        }
        if (rainbow) {
            glDepthRangef(1, 0.5);
            performRGBChange();
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_COLOR, GL_CONSTANT_COLOR);
            glBlendEquation(GL_FUNC_ADD);
            glBlendColor(redd*3.92156863*0.001, greenn*3.92156863*0.001, bluee*3.92156863*0.001, 1.000);
            glDepthFunc(GL_ALWAYS);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
            glColorMask(redd,greenn, bluee, 255);
            glBlendFunc(GL_DST_COLOR, GL_ONE);
            glDepthFunc(GL_LESS);
            glDepthMask(true);
            glDepthMask(false);
            glBlendColor(0.0, 0.0, 0.0, 0.0);
        }
        if (wire) {
            glEnable(GL_CULL_FACE);
            glCullFace(GL_BACK);
            glEnable(GL_BLEND);
            glDepthFunc(GL_ALWAYS);
            glDepthMask(false);
            glBlendFunc(GL_CONSTANT_COLOR, GL_ZERO);
            glColorMask(r,g, b, 1.0f);
            glEnable(GL_POLYGON_OFFSET_FILL);
            glPolygonOffset(-2.5f, -2.5f);
            glLineWidth(linewidth);
            old_glDrawElements(GL_LINE_LOOP, count, type, indices);
            glDepthFunc(GL_LESS);
            glBlendFunc(GL_ONE, GL_ZERO);
            glColorMask(r,g, b, 0.8f);
            glDisable(GL_POLYGON_OFFSET_FILL);
        }
        if (glow) {
            glEnable(GL_BLEND);
            glLineWidth(linewidth);
            glDepthMask(true);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glBlendColor(0.0, 0.0, 0.0, 0.1);
            glDepthFunc(GL_ALWAYS);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
            glColorMask(r,g, b, 255);
            glBlendFunc(GL_DST_COLOR, GL_ONE);
            glDepthFunc(GL_LESS);
            glDepthMask(true);
            glDepthMask(false);
            glBlendColor(0.0, 0.0, 0.0, 0.0);

            old_glDrawElements(GL_LINE_LOOP, count, type, indices);
        }
        if (outline) {
            glDepthRangef(1, 0);
            performRGBChange();
            glLineWidth(linewidth);
            glEnable(GL_BLEND);
            glColorMask(1, 1, 1, 1);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glBlendFuncSeparate(GL_CONSTANT_COLOR, GL_CONSTANT_ALPHA, GL_ONE, GL_ZERO);
            glBlendColor(0, 0, 0, 1);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
            glBlendColor(GLfloat(redd/100), GLfloat(greenn/100), GLfloat(bluee/100), 1);
            glDepthRangef(1, 0.5);
            glBlendColor(GLfloat(float(redd)/255), GLfloat(float(greenn)/255), GLfloat(float(bluee)/255), 1);
            old_glDrawElements(GL_LINES, count, type, indices);
        }
        if (defchams) {
            glDepthRangef(1, 0.5);
            performRGBChange();
            performRGBChange();
            glColorMask (r, g, b, 1);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glBlendEquation(GL_FUNC_ADD);
            glBlendColor(r*3.92156863*0.001, g*3.92156863*0.001, b*3.92156863*0.001, 1.000);
        }
        old_glDrawElements(mode, count, type, indices);
        glDepthMask(true);
        glDepthFunc(GL_LESS);
        glDepthRangef(0.5, 1);
        glColorMask(1, 1, 1, 1);
        glDisable(GL_BLEND);
    }
}

bool mlovinit(){
    handle = NULL;
    handle = dlopen("libGLESv2.so", RTLD_LAZY);
    if(!handle){
        return false;
    }
    return true;
}
#endif///By CMODs
