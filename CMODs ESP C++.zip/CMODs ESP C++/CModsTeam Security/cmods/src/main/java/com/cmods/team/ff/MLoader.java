package com.cmods.team.ff;

import android.app.AlertDialog;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.widget.Switch;
import android.widget.CompoundButton;
import android.text.Html;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.CheckBox;
import android.util.Base64;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.app.ActivityManager;
import android.content.res.AssetManager;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.os.Message;
import android.graphics.Point;
import android.content.res.ColorStateList;

public class MLoader extends Service {

    private WindowManager mWindowManager;
    private FrameLayout frameLayout;
    private RelativeLayout collapse_view;
    private LinearLayout expanded_container;
    private ImageView close_btn;
    private TextView txtUsuarioValidade;
    
	private LinearLayout linearLayout_com_botoes;

	private View overlayView;

	private WindowManager.LayoutParams espParams;

	private ImageView LogoIp;

	private LinearLayout linearLayout_com_botoes2;

	private ImageView btnClose2;

	private LinearLayout linearLayoutPrincipal2x;

	private LinearLayout linearLayoutPrincipal2;

	private LinearLayout infocriador;

	private LinearLayout linhainfo;

	public native void Changes(int feature, int Value);
    private native String Title();
    private native String Icon();
	private native String fechax();
	private native int IconSize();
    private native String Heading();
    private native String pika();
    private native String[] getFeatureListttttttttt();
	
	String GetNamePackage = "com.dts.freefireth";
	String GetLibrary = "/lib/"+"libil2cpp.so";
	String VersionGame = "V"+"1.68.1";
	String NameLibModify = "/"+"libcmods.so";
	
	float density;
	int dpi;
    Handler handler;
	int screenHeight;
    int screenWidth;
    long sleepTime;
    int type;
    CanvasView canvasLayout;
    LayoutParams canvasLayoutParams;
    Thread mThread;
    Thread mUpdateFloating;
	WindowManager windowManager;
	
		private class CanvasView extends View {
        public CanvasView(Context context) {
            super(context);
        }
        public void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (canvas != null) {
                MLoader.onDraw1(canvas, MLoader.this.screenWidth, MLoader.this.screenHeight, MLoader.this.density);
            }
        }
    }
    public MLoader() {
        this.sleepTime = 16;
        this.handler = new Handler() {
            public void handleMessage(Message message) {
                super.handleMessage(message);
                if (message.what == 0) {
                    try {
                        Point point = new Point();
                        MLoader.this.windowManager.getDefaultDisplay().getRealSize(point);
                        MLoader.this.screenWidth = point.x;
                        MLoader.this.screenHeight = point.y;
                        MLoader.this.canvasLayoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                        MLoader.this.canvasLayoutParams.height = WindowManager.LayoutParams.MATCH_PARENT;
                        MLoader.this.windowManager.updateViewLayout(MLoader.this.canvasLayout, MLoader.this.canvasLayoutParams);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };
        };
		this.mThread = new Thread() {
            public void run() {
                Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                while (isAlive() && !isInterrupted()) {
                    try {
                        long currentTimeMillis = System.currentTimeMillis();
                        MLoader.this.canvasLayout.postInvalidate();
                        Thread.sleep(Math.max(Math.min(0, MLoader.this.sleepTime - (System.currentTimeMillis() - currentTimeMillis)), MLoader.this.sleepTime));
                    } catch (Exception e) {
						e.printStackTrace();
                    }
                }
            }
        };
        this.mUpdateFloating = new Thread() {
            public void run() {
				Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                while (isAlive() && !isInterrupted()) {
					try {
                        long currentTimeMillis = System.currentTimeMillis();
                        Point point = new Point();
                        MLoader.this.windowManager.getDefaultDisplay().getRealSize(point);
                        if (!(MLoader.this.screenWidth == point.x && MLoader.this.screenHeight == point.y)) {
                            MLoader.this.handler.sendEmptyMessage(0);
                        }
                        Thread.sleep(Math.max(Math.min(0, MLoader.this.sleepTime - (System.currentTimeMillis() - currentTimeMillis)), MLoader.this.sleepTime));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        };
    }
	
	private static native void onDraw1(Canvas canvas, int i, int i2, float f);
	
    private void setupMenu(){
        frameLayout = new FrameLayout(this);
        FrameLayout.LayoutParams fraLayoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        frameLayout.setLayoutParams(fraLayoutParams);

        RelativeLayout root_container = new RelativeLayout(this);
        RelativeLayout.LayoutParams relativeLayoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
		root_container.setLayoutParams(relativeLayoutParams);
		
		btnClose2 =new ImageView(this);
		LinearLayout.LayoutParams btnClose_param1s = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32));
        btnClose_param1s.topMargin = dp(1);
		btnClose2.setLayoutParams(btnClose_param1s);
		
		int applyDimensioncl = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        btnClose2.getLayoutParams().height = applyDimensioncl;
        btnClose2.getLayoutParams().width = applyDimensioncl;
        btnClose2.requestLayout();
        btnClose2.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decodecl = Base64.decode(Icon(), 0);
        btnClose2.setImageBitmap(BitmapFactory.decodeByteArray(decodecl, 0, decodecl.length));
        btnClose2.setImageAlpha(999);
        ((ViewGroup.MarginLayoutParams) btnClose2.getLayoutParams()).topMargin = convertDipToPixels(1);
		root_container.addView(btnClose2);
		
		/*
		btnClose2 =new Button(this);
		LinearLayout.LayoutParams btnClose_param1s = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32));
        btnClose_param1s.topMargin = dp(1);
		btnClose2.setLayoutParams(btnClose_param1s);
        btnClose2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        btnClose2.setTypeface(null, Typeface.BOLD);
        btnClose2.setTextColor(Color.parseColor("#ffffff"));
		btnClose2.setText("Close");
		btnClose2.setBackgroundColor(Color.parseColor("#0a2fff"));
		btnClose2.setVisibility(View.GONE);
		root_container.addView(btnClose2);
		*/
		
        collapse_view = new RelativeLayout(this);
        collapse_view.setLayoutParams(relativeLayoutParams);
		
        ImageView collapsed_iv = new ImageView(this);
        LinearLayout.LayoutParams collapsed_ivparams = new LinearLayout.LayoutParams(dp(150), LinearLayout.LayoutParams.WRAP_CONTENT);
		collapsed_ivparams.gravity = Gravity.CENTER;
        collapsed_iv.setLayoutParams(collapsed_ivparams);
		int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        collapsed_iv.getLayoutParams().height = applyDimension;
        collapsed_iv.getLayoutParams().width = applyDimension;
        collapsed_iv.requestLayout();
        collapsed_iv.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        collapsed_iv.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        collapsed_iv.setImageAlpha(999);
        ((ViewGroup.MarginLayoutParams) collapsed_iv.getLayoutParams()).topMargin = convertDipToPixels(1);
		collapse_view.addView(collapsed_iv);
     
        expanded_container = new LinearLayout(this);
        LinearLayout.LayoutParams expanded_containerParams = new LinearLayout.LayoutParams(dp(320/*400*/), LinearLayout.LayoutParams.WRAP_CONTENT);
		expanded_containerParams.gravity = Gravity.CENTER;
		expanded_containerParams.topMargin = dp(60/*35*/);
        expanded_container.setLayoutParams(expanded_containerParams);
        expanded_container.setOrientation(LinearLayout.VERTICAL);
        expanded_container.setBackgroundColor(Color.parseColor("#0a2fff"));
        expanded_container.setVisibility(View.GONE);
		
		
		LinearLayout bordnomemenu = new LinearLayout(this);
        LinearLayout.LayoutParams bordnomemenuzin = new LinearLayout.LayoutParams(dp(330/*400*/), dp(25/*45*/));
        bordnomemenu.setLayoutParams(bordnomemenuzin);
		bordnomemenuzin.gravity = Gravity.CENTER_HORIZONTAL;
       // bordnomemenuzin.bottomMargin = dp(5);
        bordnomemenu.setOrientation(LinearLayout.HORIZONTAL);
		bordnomemenu.setBackgroundColor(Color.parseColor("#12efff"));
		
		
		TextView eccccm = new TextView(this);
        LinearLayout.LayoutParams initmmm = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        initmmm.gravity = Gravity.CENTER;
        initmmm.leftMargin = dp(60);
        eccccm.setLayoutParams(initmmm);
        eccccm.setTypeface(null,Typeface.BOLD);
        eccccm.setText("Mod Menu by CMODS Team");///NOME DO MENU A CIMA
        eccccm.setTextColor(Color.parseColor("#000000"));
		eccccm.setTextSize(12.0f);
		bordnomemenu.addView(eccccm);
		
        LinearLayout linearLayoutPrincipal = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParamsLinearLayoutPrincipal = new LinearLayout.LayoutParams(dp(330/*400*/), dp(350/*300*/));//LinearLayout.LayoutParams.WRAP_CONTENT
		layoutParamsLinearLayoutPrincipal.gravity = Gravity.CENTER;
        linearLayoutPrincipal.setLayoutParams(layoutParamsLinearLayoutPrincipal);
       // linearLayoutPrincipal.setBackgroundColor(Color.parseColor("#3e060000"));
        linearLayoutPrincipal.setOrientation(LinearLayout.VERTICAL);
        
		LinearLayout IconAcima = new LinearLayout(this);
        LinearLayout.LayoutParams IconAcimaP = new LinearLayout.LayoutParams(dp(330/*400*/), dp(30/*45*/));
        IconAcima.setLayoutParams(IconAcimaP);
		IconAcimaP.gravity = Gravity.CENTER_HORIZONTAL;
        IconAcima.setOrientation(LinearLayout.HORIZONTAL);
		IconAcima.setBackgroundColor(Color.parseColor("#3e060000"));
		
		final TextView infobutton = new TextView(this);
		LinearLayout.LayoutParams information_param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		information_param.gravity = Gravity.CENTER;
        information_param.leftMargin = dp(40/*65*/);
        infobutton.setLayoutParams(information_param);
        infobutton.setText("MENU INFO" + " | ");
        infobutton.setTypeface(Typeface.SERIF);
        infobutton.setTextColor(Color.parseColor("#ffffecd9"));
		infobutton.setTextSize(11.0f);
		
		
        final TextView CoRingaModzTVV = new TextView(this);
		LinearLayout.LayoutParams titull_param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		titull_param.gravity = Gravity.CENTER;
        titull_param.leftMargin = dp(10);
        CoRingaModzTVV.setLayoutParams(titull_param);
        CoRingaModzTVV.setText("MENU AIMBOT" + " | ");
        CoRingaModzTVV.setTypeface(Typeface.SERIF);
        CoRingaModzTVV.setTextColor(Color.parseColor("#ffffecd9"));
		CoRingaModzTVV.setTextSize(11.0f);
		
		final TextView CoRingaModzTVVx = new TextView(this);
		LinearLayout.LayoutParams titull_paramx = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		titull_paramx.gravity = Gravity.CENTER;
		titull_paramx.leftMargin = dp(10);
		CoRingaModzTVVx.setLayoutParams(titull_paramx);
        CoRingaModzTVVx.setText("MENU ESP");
        CoRingaModzTVVx.setTypeface(Typeface.SERIF);
        CoRingaModzTVVx.setTextColor(Color.parseColor("#ffffecd9"));
		CoRingaModzTVVx.setTextSize(11.0f);
		
		CoRingaModzTVVx.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					infobutton.setTextColor(Color.parseColor("#ffffecd9"));
					CoRingaModzTVV.setTextColor(Color.parseColor("#ffffecd9"));
					CoRingaModzTVVx.setTextColor(Color.parseColor("#ff0303"));
                    linearLayoutPrincipal2x.setVisibility(View.VISIBLE);
					linearLayoutPrincipal2.setVisibility(View.GONE);
					infocriador.setVisibility(View.GONE);
				}
			});
		infobutton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					infobutton.setTextColor(Color.parseColor("#ff0303"));
					CoRingaModzTVV.setTextColor(Color.parseColor("#ffffecd9"));
					CoRingaModzTVVx.setTextColor(Color.parseColor("#ffffecd9"));
					linearLayoutPrincipal2.setVisibility(View.GONE);
					linearLayoutPrincipal2x.setVisibility(View.GONE);
					infocriador.setVisibility(View.VISIBLE);
				}
			});
		CoRingaModzTVV.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					infobutton.setTextColor(Color.parseColor("#ffffecd9"));
					CoRingaModzTVV.setTextColor(Color.parseColor("#ff0303"));
					CoRingaModzTVVx.setTextColor(Color.parseColor("#ffffecd9"));
                    linearLayoutPrincipal2.setVisibility(View.VISIBLE);
					linearLayoutPrincipal2x.setVisibility(View.GONE);
					infocriador.setVisibility(View.GONE);
				}
			});
		
			
		IconAcima.addView(infobutton);	
		IconAcima.addView(CoRingaModzTVV);	
		IconAcima.addView(CoRingaModzTVVx);
		
		linearLayoutPrincipal2 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParamsLinearLayoutPrincipal2 = new LinearLayout.LayoutParams(dp(293/*300*/), LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParamsLinearLayoutPrincipal2.gravity = Gravity.CENTER;
		linearLayoutPrincipal2.setLayoutParams(layoutParamsLinearLayoutPrincipal2);
		// linearLayoutPrincipal2.setBackgroundColor(Color.parseColor("#3e060000"));
        linearLayoutPrincipal2.setOrientation(LinearLayout.HORIZONTAL);
		linearLayoutPrincipal2.setVisibility(View.GONE);
		
		linearLayoutPrincipal2x = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayoutPrincipalX = new LinearLayout.LayoutParams(dp(293/*300*/), LinearLayout.LayoutParams.WRAP_CONTENT);
        linearLayoutPrincipalX.gravity = Gravity.CENTER;
		linearLayoutPrincipal2x.setLayoutParams(linearLayoutPrincipalX);
        linearLayoutPrincipal2x.setOrientation(LinearLayout.HORIZONTAL);
		linearLayoutPrincipal2x.setVisibility(View.GONE);
		
		infocriador = new LinearLayout(this);
        LinearLayout.LayoutParams infocriadorL = new LinearLayout.LayoutParams(dp(293/*300*/), LinearLayout.LayoutParams.WRAP_CONTENT);
        infocriadorL.gravity = Gravity.CENTER;
		infocriador.setLayoutParams(infocriadorL);
        infocriador.setOrientation(LinearLayout.HORIZONTAL);
		
        ScrollView scrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollView_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
        scrollView.setLayoutParams(scrollView_Params);

		this.linearLayout_com_botoes = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__com_botoes_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
        linearLayout_com_botoes.setLayoutParams(linearLayout__com_botoes_Params);
        linearLayout_com_botoes.setOrientation(LinearLayout.VERTICAL);
        
        ScrollView scrollView2 = new ScrollView(this);
        LinearLayout.LayoutParams scrollView_Params2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
        scrollView2.setLayoutParams(scrollView_Params2);
		
		this.linearLayout_com_botoes2 = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__com_botoes_Params2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
        linearLayout_com_botoes2.setLayoutParams(linearLayout__com_botoes_Params2);
        linearLayout_com_botoes2.setOrientation(LinearLayout.VERTICAL);
		//linearLayout_com_botoes2.setVisibility(View.GONE);
		
		ScrollView scrollViewinfo = new ScrollView(this);
        LinearLayout.LayoutParams scrollView_info = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
        scrollViewinfo.setLayoutParams(scrollView_info);

		this.linhainfo = new LinearLayout(this);
        LinearLayout.LayoutParams linearLayout__info = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.FILL_PARENT);
        linhainfo.setLayoutParams(linearLayout__info);
        linhainfo.setOrientation(LinearLayout.VERTICAL);
		/*
		TextView nomeJogoVersao = new TextView(this);
        LinearLayout.LayoutParams nomeJogoVersao_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nomeJogoVersao_Params.gravity = Gravity.CENTER;
        nomeJogoVersao_Params.topMargin = dp(12);
        nomeJogoVersao_Params.bottomMargin = dp(12);
        nomeJogoVersao.setLayoutParams(nomeJogoVersao_Params);
        nomeJogoVersao.setTypeface(null,Typeface.BOLD);
        nomeJogoVersao.setText("information :\n"+"Team : DevTeam\nCredits : CoRingaModz\nTelegram : @CoRingaModzYT\n\nLogCat Game : \n[+] Package : " + GetNamePackage + "\n[+] Version Game : "+VersionGame+"\n[+] Game NativeDir : "+GetLibrary+"\n[+] Game Process : "+NameLibModify+"\n[+] ABI : " + Build.CPU_ABI +"\n[+] ABI2 : "+Build.CPU_ABI2);///INFORMAÇÃO
        nomeJogoVersao.setTextColor(Color.parseColor("#f70505"));
		nomeJogoVersao.setTextSize(12.0f);
		linhainfo.addView(nomeJogoVersao);
		*/
		addSeekBarInfo(3, "MENU - CAPACIDADE", 1, 100, 100, "", "%", new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					expanded_container.setAlpha((float) progress / 100.f);
					btnClose2.setAlpha((float) progress / 20.f);
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {

				}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
				}
			});
		
        addColor(3, "COLOR MENU", new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBarx, int progress, boolean fromUser) {
					//expanded_container.setAlpha((float) progress / 100.f);
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBarx) {

				}
				@Override
				public void onStopTrackingTouch(SeekBar seekBarx) {
				}
			});
       
		scrollViewinfo.addView(linhainfo);
        scrollView.addView(linearLayout_com_botoes);
		scrollView2.addView(linearLayout_com_botoes2);
		
		linearLayoutPrincipal.addView(bordnomemenu);
        linearLayoutPrincipal.addView(IconAcima);
		
		infocriador.addView(scrollViewinfo);
        linearLayoutPrincipal2.addView(scrollView);
		linearLayoutPrincipal2x.addView(scrollView2);
	
		linearLayoutPrincipal.addView(infocriador);
		
		linearLayoutPrincipal.addView(linearLayoutPrincipal2);
		
		linearLayoutPrincipal.addView(linearLayoutPrincipal2x);
		
        expanded_container.addView(linearLayoutPrincipal);
		
		root_container.addView(collapse_view);
        root_container.addView(expanded_container);
		
        frameLayout.addView(root_container);
		MrEzCheatsYT();
    }
	
	
	public void CreateCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.canvasLayoutParams = layoutParams = new WindowManager.LayoutParams(-1, -1, getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.canvasLayoutParams.x = 0;
        this.canvasLayoutParams.y = 0;
		CanvasView canvasView = new CanvasView(this);
        this.canvasLayout = canvasView;
        this.windowManager.addView(canvasView, this.canvasLayoutParams);
		this.sleepTime = 16;
    }
	
    @Override
    public void onCreate() {
        super.onCreate();
		this.windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Point point = new Point();
        this.windowManager.getDefaultDisplay().getRealSize(point);
        this.screenWidth = point.x;
        this.screenHeight = point.y;
        this.dpi = Resources.getSystem().getDisplayMetrics().densityDpi;
        this.density = Resources.getSystem().getDisplayMetrics().density;
        this.type = getLayoutType();
        CreateCanvas();
        this.mThread.start();
        this.mUpdateFloating.start();
		System.loadLibrary("cmods");
        setupMenu();
		final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    MLoader.this.Thread();
                    handler.postDelayed(this, 1000);
                }
            });
        int flag;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1){
            flag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        else {
            flag = WindowManager.LayoutParams.TYPE_PHONE;
        }

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,flag, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(frameLayout, params);
		btnClose2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
                    collapse_view.setVisibility(View.VISIBLE);
					btnClose2.setVisibility(View.GONE);
                    expanded_container.setVisibility(View.GONE);
				}
			});
        frameLayout.setOnTouchListener(new View.OnTouchListener() {
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int Xdiff = (int) (event.getRawX() - initialTouchX);
                        int Ydiff = (int) (event.getRawY() - initialTouchY);
                        if (Xdiff < 10 && Ydiff < 10) {
                            if (isViewCollapsed()) {
                               collapse_view.setVisibility(View.GONE);
                                expanded_container.setVisibility(View.VISIBLE);
								btnClose2.setVisibility(View.VISIBLE);
								collapse_view.setAlpha(0.8f);
									//expanded_container.setAlpha(0.8f);
									
                                }
                            
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        mWindowManager.updateViewLayout(frameLayout, params);
                        return true;
                }
                return false;
            }
        });
}
	private void MrEzCheatsYT(){
		String[] arrstring = this.getFeatureListttttttttt();
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            final int n2 = i2;
            String string2 = arrstring[i2];
            if (string2.contains((CharSequence)"Toggle_")) {
                this.addVisip(string2.replace((CharSequence)"Toggle_", (CharSequence)""), new InterfaceBool(){
                        @Override
                        public void OnWrite(boolean bl) {
                            MLoader.this.Changes(n2, 0);
                        }
                    });
                continue;
            }
			if (string2.contains((CharSequence)"ToggleAIMBOT_")) {
                this.addAimbot(string2.replace((CharSequence)"ToggleAIMBOT_", (CharSequence)""), new InterfaceBool(){
                        @Override
                        public void OnWrite(boolean bl) {
                            MLoader.this.Changes(n2, 0);
                        }
                    });
                continue;
            }
            if (string2.contains((CharSequence)"SeekBar_")) {
                String[] arrstring2 = string2.split("_");
                this.addSeekBar(arrstring2[1], Integer.parseInt((String)arrstring2[2]), Integer.parseInt((String)arrstring2[3]), new InterfaceInt(){
                        @Override
                        public void OnWrite(int n22) {
                            MLoader.this.Changes(n2, n22);
                        }
                    });
                continue;
            }
			if (string2.contains((CharSequence)"SeekBar2_")) {
                String[] arrstring2 = string2.split("_");
                this.addSeekBarESP(arrstring2[1], Integer.parseInt((String)arrstring2[2]), Integer.parseInt((String)arrstring2[3]), new InterfaceInt(){
                        @Override
                        public void OnWrite(int n22) {
                            MLoader.this.Changes(n2, n22);
                        }
                    });
                continue;
            }
			if (string2.contains("Category_")) {
				this.addCategory(string2.replace("Category_", ""));
			}
			if (string2.contains("Category2_")) {
				this.addCategory2(string2.replace("Category2_", ""));
			}
		}
	}
	private void addAimbot(String string2, final InterfaceBool interfaceBool) {
        final Switch swbot = new Switch(this);
        swbot.setText(string2);
        swbot.setTextColor(Color.WHITE);
        swbot.setPadding(10, 3, 3, 3);
        swbot.setTextSize(12.0f);

		final GradientDrawable BackgroundCaixa = new GradientDrawable();
        BackgroundCaixa.setShape(0);
        BackgroundCaixa.setColor(-1);
        BackgroundCaixa.setCornerRadius((float) dp(10));
        BackgroundCaixa.setSize(dp(20), dp(20));
        BackgroundCaixa.setStroke(dp(1), -7829368);
        final GradientDrawable BackgrounSwitch = new GradientDrawable();
        BackgrounSwitch.setShape(0);
        BackgrounSwitch.setColor(-1);
        BackgrounSwitch.setStroke(dp(1), -7829368);
        BackgrounSwitch.setCornerRadius((float) dp(10));
        BackgrounSwitch.setSize(dp(20), dp(20));
        swbot.setTrackDrawable(BackgroundCaixa);
        swbot.setThumbDrawable(BackgrounSwitch);

        swbot.setTypeface(swbot.getTypeface(), Typeface.BOLD);
        swbot.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
						BackgrounSwitch.setStroke(dp(1), Color.parseColor("#FF0000"));
						BackgroundCaixa.setStroke(dp(1), Color.parseColor("#FF0000"));
						BackgroundCaixa.setColor(Color.parseColor("#FF0000"));
						//swbot.setTextColor(Color.parseColor("#ffff0000"));
					} else {
						BackgrounSwitch.setStroke(dp(1), -7829368);
						BackgroundCaixa.setStroke(dp(1), -7829368);
						BackgroundCaixa.setColor(-1);
                       // swbot.setTextColor(Color.WHITE);
                    }
                }
            });
        this.linearLayout_com_botoes.addView(swbot);
    }
    private void addVisip(String string2, final InterfaceBool interfaceBool) {
        final Switch sw = new Switch(this);
        sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(12.0f);
		
		final GradientDrawable BackgroundCaixa = new GradientDrawable();
        BackgroundCaixa.setShape(0);
        BackgroundCaixa.setColor(-1);
        BackgroundCaixa.setCornerRadius((float) dp(10));
        BackgroundCaixa.setSize(dp(20), dp(20));
        BackgroundCaixa.setStroke(dp(1), -7829368);
        final GradientDrawable BackgrounSwitch = new GradientDrawable();
        BackgrounSwitch.setShape(0);
        BackgrounSwitch.setColor(-1);
        BackgrounSwitch.setStroke(dp(1), -7829368);
        BackgrounSwitch.setCornerRadius((float) dp(10));
        BackgrounSwitch.setSize(dp(20), dp(20));
        sw.setTrackDrawable(BackgroundCaixa);
        sw.setThumbDrawable(BackgrounSwitch);
		
        sw.setTypeface(sw.getTypeface(), Typeface.BOLD);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
						BackgrounSwitch.setStroke(dp(1), Color.parseColor("#FF0000"));
						BackgroundCaixa.setStroke(dp(1), Color.parseColor("#FF0000"));
						BackgroundCaixa.setColor(Color.parseColor("#FF0000"));
                      //   sw.setTextColor(Color.parseColor("#ffff0000"));
					} else {
						BackgrounSwitch.setStroke(dp(1), -7829368);
						BackgroundCaixa.setStroke(dp(1), -7829368);
						BackgroundCaixa.setColor(-1);
                       // sw.setTextColor(Color.WHITE);
                    }
                }
            });
        this.linearLayout_com_botoes2.addView(sw);
    }
    private void addCategory(String text) {
        TextView textView11 = new TextView(this);
        textView11.setText(text);
        textView11.setGravity(17);
        textView11.setTextSize(12.0f);
        // textView11.setShadowLayer(18.0f, 0.0f, 0.0f, Color.parseColor("#ffFFFF00"));
        textView11.setTextColor(Color.parseColor("#FFffffff"));
        textView11.setTypeface(null, Typeface.BOLD);
        textView11.setPadding(10, 5, 0, 5);
		this.linearLayout_com_botoes.addView(textView11);
    }

	private void addCategory2(String text) {
        TextView textView11 = new TextView(this);
        textView11.setText(text);
        textView11.setGravity(17);
        textView11.setTextSize(12.0f);
        // textView11.setShadowLayer(18.0f, 0.0f, 0.0f, Color.parseColor("#ffFFFF00"));
        textView11.setTextColor(Color.parseColor("#FFffffff"));
        textView11.setTypeface(null, Typeface.BOLD);
        textView11.setPadding(10, 5, 0, 5);
        this.linearLayout_com_botoes2.addView(textView11);
    }
    private void addSeekBar(String str, int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));
        TextView textView = new TextView(this);
        StringBuilder sb2 = new StringBuilder();
        //sb2.append("<font face='monospace'><b>");
        sb2.append(str);
        sb2.append(": <font color='WHITE'>");
        sb2.append(progress);
        sb2.append("x"+"</b></font>");
        textView.setText(Html.fromHtml(sb2.toString()));
		textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.0f);
        textView.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);

        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
		
		GradientDrawable CMODSB = new GradientDrawable();
        CMODSB.setShape(1);
       // CMODSB.setColor(Color.parseColor("#000000"));
        CMODSB.setStroke(5, Color.parseColor("#ff00c3d6"));
        CMODSB.setCornerRadius(25.0f);
        CMODSB.setSize(dp(17), dp(17));
        seekBar.setThumb(CMODSB);

        seekBar.setScaleY(1.0f);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

        if (Build.VERSION.SDK_INT >= 21) {
            seekBar.getProgressDrawable().setTint(-1);
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#ff00c3d6"), PorterDuff.Mode.MULTIPLY);
		//  seekBar.getThumb().setColorFilter(Color.parseColor("#fff90000"), PorterDuff.Mode.SRC_IN);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;
        final TextView textView2 = textView;
        final String str3 = str;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                private String itv;
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    int i2 = i5;
                    if (i < i2) {
                        seekBar2.setProgress(i2);
                        sb3.OnWrite(i5);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml(str3 + ": <font color='WHITE'>" + i5 + "x" + "</b></font>"));
                        return;
                    }
                    sb3.OnWrite(i);
                    textView2.setText(Html.fromHtml(str3 + ": <font color='WHITE'>" + i + "x" + "</b></font>"));

                }
            });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
		// linearLayout.setLayoutParams(this.hr);
        this.linearLayout_com_botoes.addView(linearLayout);
    }
	
	private void addSeekBarESP(String str, int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));
        TextView textView = new TextView(this);
        StringBuilder sb2 = new StringBuilder();
        //sb2.append("<font face='monospace'><b>");
        sb2.append(str);
        sb2.append(": <font color='WHITE'>");
        sb2.append(progress);
        sb2.append("x"+"</b></font>");
        textView.setText(Html.fromHtml(sb2.toString()));
		textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.0f);
        textView.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);

        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);

		GradientDrawable CMODSB = new GradientDrawable();
        CMODSB.setShape(1);
		// CMODSB.setColor(Color.parseColor("#000000"));
        CMODSB.setStroke(5, Color.parseColor("#ff00c3d6"));
        CMODSB.setCornerRadius(25.0f);
        CMODSB.setSize(dp(17), dp(17));
        seekBar.setThumb(CMODSB);

        seekBar.setScaleY(1.0f);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

        if (Build.VERSION.SDK_INT >= 21) {
            seekBar.getProgressDrawable().setTint(-1);
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#ff00c3d6"), PorterDuff.Mode.MULTIPLY);
		//  seekBar.getThumb().setColorFilter(Color.parseColor("#fff90000"), PorterDuff.Mode.SRC_IN);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;
        final TextView textView2 = textView;
        final String str3 = str;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                private String itv;
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    int i2 = i5;
                    if (i < i2) {
                        seekBar2.setProgress(i2);
                        sb3.OnWrite(i5);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml(str3 + ": <font color='WHITE'>" + i5 + "x" + "</b></font>"));
                        return;
                    }
                    sb3.OnWrite(i);
                    textView2.setText(Html.fromHtml(str3 + ": <font color='WHITE'>" + i + "x" + "</b></font>"));

                }
            });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
		// linearLayout.setLayoutParams(this.hr);
        this.linearLayout_com_botoes2.addView(linearLayout);
    }
    private void addColor(int progress,String p1, Object onStopTrackingTouch) {
		LinearLayout linearLayoutcolor = new LinearLayout(this);
        LinearLayout.LayoutParams buceta = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        linearLayoutcolor.setPadding(10, 5, 0, 5);
        linearLayoutcolor.setOrientation(1);
        linearLayoutcolor.setGravity(17);
        linearLayoutcolor.setLayoutParams(buceta);
        linearLayoutcolor.setBackgroundColor(Color.parseColor("#00000000"));
		final TextView textView = new TextView(this);
		textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		//textView.setLayoutParams(buceta);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.0f);
        textView.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
		textView.setPadding(15, 15, 15, 15);
        textView.setTextColor(-1);
		textView.setText("Color Menu - All");
		SeekBar seekBarx = new SeekBar(this); 
		GradientDrawable CMODSB2 = new GradientDrawable();
        CMODSB2.setShape(1);
        CMODSB2.setStroke(5, Color.parseColor("#ff00c3d6"));
        CMODSB2.setCornerRadius(25.0f);
        CMODSB2.setSize(dp(17), dp(17));
        seekBarx.setThumb(CMODSB2);
        seekBarx.setMax(5);
		seekBarx.setProgress(progress);
		seekBarx.getProgressDrawable().setColorFilter(Color.parseColor("#ff00c3d6"), PorterDuff.Mode.MULTIPLY);
        seekBarx.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBarx.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBarx, int progress, boolean z) {
					if(progress == 0) {
						textView.setText(Html.fromHtml("Padrão Color" + " : <font color='#ffffff'>" + " Azul" + "</font>"));
						expanded_container.setBackgroundColor(Color.parseColor("#252625"));
						//btnClose2.setBackgroundColor(Color.parseColor("#0000FF"));
						}else if(progress == 1) {
							textView.setText(Html.fromHtml("Menu Color" + " : <font color='#ffffff'>" + " Verde" + "</font>"));
						expanded_container.setBackgroundColor(Color.parseColor("#00FF00"));
						//btnClose2.setBackgroundColor(Color.parseColor("#00FF00"));
						}else if(progress == 2) {
							textView.setText(Html.fromHtml("Menu Color" + " : <font color='#ffffff'>" + " Vermelho" + "</font>"));
						expanded_container.setBackgroundColor(Color.parseColor("#FF0000"));
						//btnClose2.setBackgroundColor(Color.parseColor("#FF0000"));
						}else if(progress == 3) {
							textView.setText(Html.fromHtml("Menu Color" + " : <font color='#ffffff'>" + " Preto" + "</font>"));
						expanded_container.setBackgroundColor(Color.parseColor("#000000"));
						//btnClose2.setBackgroundColor(Color.parseColor("#000000"));
						}else if(progress == 4) {
							textView.setText(Html.fromHtml("Menu Color" + " : <font color='#ffffff'>" + " Ciano" + "</font>"));
						expanded_container.setBackgroundColor(Color.parseColor("#00FFFF"));
						//btnClose2.setBackgroundColor(Color.parseColor("#00FFFF"));
						}else if(progress == 5) {
							textView.setText(Html.fromHtml("Menu Color" + " : <font color='#ffffff'>" + " Roxo" + "</font>"));
						expanded_container.setBackgroundColor(Color.parseColor("#A020F0"));
						///btnClose2.setBackgroundColor(Color.parseColor("#A020F0"));
					}
                }
				@Override
				public void onStartTrackingTouch(SeekBar p1) {
				}

				@Override
				public void onStopTrackingTouch(SeekBar p1) {
				}
			});
		linearLayoutcolor.addView(textView);
		linearLayoutcolor.addView(seekBarx);
		linhainfo.addView(linearLayoutcolor);
	}

	private void addSeekBarInfo(Object data, String text, int min, int max, int value, final String prefix, final String suffix, final SeekBar.OnSeekBarChangeListener listener) {
        LinearLayout fundoinfoLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        fundoinfoLayout.setPadding(10, 5, 0, 5);
        fundoinfoLayout.setOrientation(1);
        fundoinfoLayout.setGravity(17);
        fundoinfoLayout.setLayoutParams(layoutParams);
        fundoinfoLayout.setBackgroundColor(Color.parseColor("#00000000"));
        TextView textV = new TextView(this);
        textV.setText(text + ":");
        textV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.0f);
        textV.setPadding(15, 15, 15, 15);
        textV.setTextColor(Color.WHITE);
        textV.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        SeekBar seekBar = new SeekBar(this);
		seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#ff00c3d6"), PorterDuff.Mode.MULTIPLY);
        seekBar.setMax(max);
        if (Build.VERSION.SDK_INT >= 26) {
            seekBar.setMin(min);
            seekBar.setProgress(min);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            GradientDrawable CMODSB2x = new GradientDrawable();
			CMODSB2x.setShape(1);
			CMODSB2x.setStroke(5, Color.parseColor("#ff00c3d6"));
			CMODSB2x.setCornerRadius(25.0f);
			CMODSB2x.setSize(dp(17), dp(17));
			seekBar.setThumb(CMODSB2x);
        }
        seekBar.setPadding(20, 15, 20, 15);
        final TextView textValue = new TextView(this);
        textValue.setText(prefix + min + suffix);
        textValue.setTextSize(14.0f);
        textValue.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        textValue.setPadding(20, 15, 20, 15);
        textValue.setTextColor(Color.WHITE);
        final int minimValue = min;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					if (progress < minimValue) {
						progress = minimValue;
						seekBar.setProgress(progress);
					}
					if (listener != null) listener.onProgressChanged(seekBar, progress, fromUser);
					textValue.setText(prefix + progress + suffix);
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
					if (listener != null) listener.onStartTrackingTouch(seekBar);
				}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
					if (listener != null) listener.onStopTrackingTouch(seekBar);
				}
			});
        if (value != 0) {
            if (value < min)
                value = min;
            if (value > max)
                value = max;
            textValue.setText(prefix + value + suffix);
            seekBar.setProgress(value);
        }
        fundoinfoLayout.addView(textV);
        fundoinfoLayout.addView(textValue);
        fundoinfoLayout.addView(seekBar);
        linhainfo.addView(fundoinfoLayout);
    }
	
    private boolean isViewCollapsed() {
        return frameLayout == null || collapse_view.getVisibility() == View.VISIBLE;
    }
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(rootIntent);
    }
    private boolean isNotInGame() {
        ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }
    private void Thread() {
        if (this.frameLayout == null) {
            return;
        }
        if (isNotInGame()) {
            this.frameLayout.setVisibility(View.INVISIBLE);
        } else {
            this.frameLayout.setVisibility(View.VISIBLE);
        }
    }
	public void Destroy() {
        super.onDestroy();
        if (frameLayout != null) {
            mWindowManager.removeView(frameLayout);
            frameLayout = null;
        }
        if (overlayView != null) {
            mWindowManager.removeView(overlayView);
            overlayView = null;
        }
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
	private int getDrawable(String str) {
        return getResID(str, "drawable");
    }
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }
    private int getResID(String str, String str2) {
        return getResources().getIdentifier(str, str2, getPackageName());
    }
    private int dp(int value){
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
	private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }
    private static interface InterfaceBool {
        public void OnWrite(boolean var1);
    }

    private static interface InterfaceBtn {
        public void OnWrite();
    }

    private static interface InterfaceInt {
        public void OnWrite(int var1);
    }

    private static interface InterfaceStr {
        public void OnWrite(String var1);
    }
}
